CREATE TRIGGER establecer_precio_clase_carta
  BEFORE INSERT
  ON clase_carta
  FOR EACH ROW
  set new.precio_v = new.precio_c/4;

