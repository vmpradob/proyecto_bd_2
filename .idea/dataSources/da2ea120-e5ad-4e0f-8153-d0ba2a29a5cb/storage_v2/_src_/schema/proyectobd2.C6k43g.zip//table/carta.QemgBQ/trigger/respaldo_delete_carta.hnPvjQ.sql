CREATE TRIGGER respaldo_delete_carta
  AFTER DELETE
  ON carta
  FOR EACH ROW
  insert into respaldobd2.carta(id_carta,imgUrl,imgFd,nombre,deleted_at) values (old.id, old.imgUrl,old.imgFd,old.nombre, now());

