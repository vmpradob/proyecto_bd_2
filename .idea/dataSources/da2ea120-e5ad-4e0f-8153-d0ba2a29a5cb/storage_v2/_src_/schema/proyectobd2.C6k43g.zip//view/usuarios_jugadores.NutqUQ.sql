CREATE VIEW usuarios_jugadores AS
  SELECT
    `proyectobd2`.`usuario`.`id`       AS `id`,
    `proyectobd2`.`usuario`.`email`    AS `email`,
    `proyectobd2`.`usuario`.`password` AS `password`,
    `proyectobd2`.`usuario`.`role`     AS `role`,
    `proyectobd2`.`jugador`.`dinero`   AS `dinero`
  FROM (`proyectobd2`.`usuario`
    JOIN `proyectobd2`.`jugador` ON ((`proyectobd2`.`jugador`.`id_usuario` = `proyectobd2`.`usuario`.`id`)));

