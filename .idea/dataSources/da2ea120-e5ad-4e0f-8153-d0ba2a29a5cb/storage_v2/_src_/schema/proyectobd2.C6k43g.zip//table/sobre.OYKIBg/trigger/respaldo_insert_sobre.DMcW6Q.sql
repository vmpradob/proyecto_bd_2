CREATE TRIGGER respaldo_insert_sobre
  AFTER INSERT
  ON sobre
  FOR EACH ROW
  insert into respaldobd2.sobre(id_sobre,precio,cant_cartas,imgUrl,imgFd,nombre,id_clase) values (new.id,new.precio,new.cant_cartas,new.imgUrl,new.imgFd,new.nombre,new.id_clase);

