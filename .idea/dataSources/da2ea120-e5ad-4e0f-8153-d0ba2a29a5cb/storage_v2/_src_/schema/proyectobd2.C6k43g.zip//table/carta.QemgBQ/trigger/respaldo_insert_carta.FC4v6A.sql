CREATE TRIGGER respaldo_insert_carta
  AFTER INSERT
  ON carta
  FOR EACH ROW
  insert into respaldobd2.carta(id_carta,imgUrl,imgFd,nombre) values (new.id, new.imgUrl,new.imgFd,new.nombre);

