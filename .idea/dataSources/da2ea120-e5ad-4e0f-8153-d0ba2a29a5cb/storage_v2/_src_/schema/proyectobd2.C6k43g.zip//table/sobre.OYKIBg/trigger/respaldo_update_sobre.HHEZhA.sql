CREATE TRIGGER respaldo_update_sobre
  AFTER UPDATE
  ON sobre
  FOR EACH ROW
  insert into respaldobd2.sobre(id_sobre,precio,cant_cartas,imgUrl,imgFd,nombre,id_clase) values (new.id,new.precio,new.cant_cartas,new.imgUrl,new.imgFd,new.nombre,new.id_clase);

